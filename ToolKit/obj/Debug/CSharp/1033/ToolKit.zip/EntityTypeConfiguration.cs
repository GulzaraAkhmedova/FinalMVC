﻿
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;

namespace $safeprojectname$
{
public class $safeprojectname$EntityTypeConfiguration : IEntityTypeConfiguration<$safeprojectname$>
{
    public void Configure(EntityTypeBuilder<$safeprojectname$> builder)
    {
        throw new NotImplementedException();
    }
}
}
